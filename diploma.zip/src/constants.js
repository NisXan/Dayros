export const UNLIKED_PHOTO = 'UNLIKED_PHOTO';
export const LIKED_PHOTO = 'LIKED_PHOTO';
export const ADD_IMAGES = 'ADD_IMAGES';
export const LOG_OUT = 'LOG_OUT';
export const LOG_IN = 'LOG_IN';


